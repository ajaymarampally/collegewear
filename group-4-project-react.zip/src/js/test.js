import React from 'react';



class Test extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            current_page:"t_shirts"
        }
    }
    render(){

        return(
            <div>

            </div>
        )
    }
}

export default Test;